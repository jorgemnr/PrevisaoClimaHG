from flask import Flask, render_template, redirect
app = Flask(__name__, # 'Client 
            # static_folder = "../dist", # Required for our purposes
            # template_folder = "../dist",  # Again, this is required
            # static_url_path="/"  # Flask will be confused if you don't do this
            )

# @app.route('/')
# def hello():
#     return redirect("/app", code=302)
# def inicio():
#     return render_template("index.html") 
# @app.route('/')
# def inicio():
#     return render_template("index.html") 
# @app.route('/about')
# def catch_all1():
#      return render_template("index.html") 
@app.route('/app', defaults={'path': ''})
@app.route('/app/<path>')
def catch_all(path):
    print(repr(path))
    # return app.send_static_file("index.html")  
    return render_template("index.html") 

app.run(host='0.0.0.0', port=81, debug=True)    